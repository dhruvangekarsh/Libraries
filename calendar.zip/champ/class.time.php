<?php
	
	require_once 'admin/config.php';
	
	$date = $_POST['date'];
	
	$query = $con->query("SELECT * FROM no_available WHERE dates='$date'") or die($con->error);
	if($query->num_rows > 0){
		$data = $query->fetch_assoc();
		$notime = explode(',',$data['times']);
	}
	
?>

<?php

function times($start, $end, $title){
	
	global $notime;
	
	$tStart = strtotime($start);
	$tEnd = strtotime($end);
	$tNow = $tStart;
	
	$time	= 	'<div class="col-sm-4">';
	$time  .= 	'<table class="table table-bordered">';
	$time  .= 	'<thead>
					<tr>
						<th>'.$title.'</th>
					</tr>
				 </thead>';
	
	while($tNow <= $tEnd){
		
		$t = date("H:i",$tNow);
		
		if ($notime !==  NULL && in_array($t, $notime)){$flag = "disable";}else{$flag = "enable";}
		
		$time .= '<tr><td><label for="'.$t.'" class="'.$flag.'"><input type="checkbox" name="time" class="times" value="'.$t.'" id="'.$t.'"/>'.$t.'</label></td></tr>';
		$tNow = strtotime('+30 minutes',$tNow);
		
	}
	
	$time  .= 	'</table>';	
	$time  .= 	'</div>';	
	
	return($time);
}
?>

<div class="row">
	<?php 
		echo times('06:00','11:30','Morning');
		echo times('12:00','16:30','Afternoon');
		echo times('17:00','21:00','Evening');
	?>
</div>
<script>

	$(document).ready(function(){
		$("#time td label.disable input").remove();
	});

	$('input:checkbox[name="time"]').change(function () {
		
		time = $(this).val();
		$("#timea").val(time);
		
		$('input:not(:checked)').parent().removeClass("active");
		$('input:checked').parent().addClass("active");
	});
</script>