<?php require_once 'admin/config.php'; require_once 'class.calendar.php'; ?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Calendar</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="style.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
</head>
<body onload="getcookies()">
	<div class="container">
		<div class="row">	
			<div class="col-md-6">
				<?php $cal = new Calendar; echo $cal->show(); ?>
				<div id="data123"></div>
			</div>
			<div class="col-md-6">
				<div id="time"></div>
			</div>
			<button id="getData" onload="getcookies()">Add Session</button>

		</div>
	</div>
</body>
<script>
$(document).ready(function(){
	$(".past label input").remove();
});
$(document).ready(function () {
    $('input:radio[name="date"]').change(function () {
        $('input:not(:checked)').parent().removeClass("active");
        $('input:checked').parent().addClass("active");
		
		date = $(this).val(); $("#datea").val(date);
		if (date.length > 0){
			$.ajax({
				type: "POST", url: "class.time.php", data: {date:date},
				success: function (response) { $("#time").html(response); },
				failure: function (response) { console.log(response);}
			});
		}
    });    
});
function getcookies(){
	$.get("getcookie.php", function(data){
		$("#data123").html(data); 
	});
}
$(document).on('click', 'button.removeTemp', function () {
	alpha = $(this).closest('tr').find('#mytempdate').val();
	$.ajax({
		type: "POST", url: "getcookie.php", data: {data:alpha},
		success: function (response) { $("#data123").html(response); location.reload();},
		failure: function (response) { console.log(response);}
	});
});
$(document).ready(function () {
	$("#getData").click(function(){			
		dates = $(".dates:checked").val(); 					
		chkArray = [];
	
		$(".times:checked").each(function() {
			chkArray.push($(this).val());
		});
						
		times = chkArray.join('-');
						
		$.ajax({
			type: "POST", url: "settempdata.php", data: {date:dates,time:times},
			success: function (response) { $("#data123").html(response);location.reload();},
			failure: function (response) { console.log(response);}
		});					
	});
});
</script>
</html>