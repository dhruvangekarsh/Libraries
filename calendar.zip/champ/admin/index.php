<?php 

require_once 'config.php';

require_once 'class.calendar.php'; require_once 'class.time.php'; ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Calendar</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<style>
*,th{text-align:center !important;}
table{table-layout: fixed;margin:50px 0;border-spacing: 0;border-collapse: collapse;}
table td{padding:0 !important;}
table th{padding:15px !important;}
table td label{width:100%;height:100%;margin:0;padding:15px;}
.past label {color: #ccc;cursor: not-allowed;}
.future{color:#333;}
.end{color:#f00;}
.current{font-weight:700;}
.current input,.future input{display:none;}
.active{background-color:#4CBB17;color:#fff;}
input[name="time[]"]{display:none;}


form{margin:50px 0;}
form input[type="text"] {width: 100%;padding: 10px;font-size:18px;border:none;}
form input[type="submit"] {background-color:#333;color:#fff;font-size:18px;font-weight:700;width:100%;border:none;padding:10px;}
.half{width:50% !important;float:left;}

</style>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
</head>
<body>
	<?php
		if(isset($_POST['save'])){
			$date = $_POST['date'];
			$time = implode(',',$_POST['time']);
			
			$query = $con->query("INSERT INTO no_available(dates,times) VALUES('$date','$time')") or die($con->error);
			
		}
	?>
	<div class="container">
		<div class="row">
			<form method="POST">
			<div class="col-md-5 col-md-offset-1">
				<?php
					$cal = new Calendar;
					echo $cal->show();
				?>
			</div>
			
			<div class="col-md-5">
				<div id="time">
					<?php 
						$tcal = new Time();
						echo $tcal->times('06:00','11:30','Morning');
						echo $tcal->times('12:00','16:30','Afternoon');
						echo $tcal->times('17:00','21:00','Evening');
					?>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-10 col-md-offset-1">
					<input type="submit" name="save" />
				</div>
 			</div>
			
			</form>
		</div>
	</div>
</body>
<script>
$(document).ready(function () {
	
	$(".past label input").remove();
	
    $('input:radio[name="date"]').change(function () {
        $('input:not(:checked)').parent().removeClass("active");
        $('input:checked').parent().addClass("active");
		
		date = $(this).val();
		$("#datea").val(date);
		
    });  
	
	$('input:checkbox[name="time[]"]').change(function () {
		
		time = $(this).val();
		$("#timea").val(time);
		
		$('input:not(:checked)').parent().removeClass("active");
		$('input:checked').parent().addClass("active");
	}); 
	
	
	
	var lastChecked = null;

	$(document).ready(function() {
		var $chkboxes = $('.timecheck');
		$chkboxes.click(function(e) {
			if(!lastChecked) {
				lastChecked = this;
				return;
			}
	
			if(e.shiftKey) {
				var start = $chkboxes.index(this);
				var end = $chkboxes.index(lastChecked);
	
				$chkboxes.slice(Math.min(start,end), Math.max(start,end)+ 1).prop('checked', lastChecked.checked);
	
			}
	
			lastChecked = this;
		});
	}); 
});
</script>
</html>