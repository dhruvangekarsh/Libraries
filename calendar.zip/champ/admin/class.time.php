<?php

class Time {
	
	function times($start, $end, $title){
		$tStart = strtotime($start);
		$tEnd = strtotime($end);
		$tNow = $tStart;
		
		$time	= 	'<div class="col-sm-4">';
		$time  .= 	'<table class="table table-bordered">';
		$time  .= 	'<thead>
						<tr>
							<th>'.$title.'</th>
						</tr>
					 </thead>';
		
		while($tNow <= $tEnd){
			$t = date("H:i",$tNow);
		  $time .= '<tr><td><label for="'.$t.'"><input type="checkbox" name="time[]" class="timecheck" value="'.$t.'" id="'.$t.'"/>'.$t.'</label></td></tr>';
		  $tNow = strtotime('+30 minutes',$tNow);
		}
		
		$time  .= 	'</table>';	
		$time  .= 	'</div>';	
		
		return($time);
	}
	
}
?>
