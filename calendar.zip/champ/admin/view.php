<?php
	require 'config.php';
	
	$query = $con->query("SELECT * FROM no_available");
	
?>
<html>
	<head>
		<title>View</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
	</head>
	<body>
		<div class="container">
			<div class="row">
				<div class="col-md-10 col-md-offset-1">
					<table class="table table-bordered">
						<tr>
							<th>Date</th>
							<th>Time</th>
						</tr>
					<?php
						while($data = $query->fetch_assoc()){
						?>
						<tr>
							<td><?php echo $data['dates']; ?></td>
							<td><?php echo $data['times']; ?></td>
						</tr>		
						<?php		
						}
					?>	
					</table>
				</div>
			</div>
		</div>
	</body>
</html>