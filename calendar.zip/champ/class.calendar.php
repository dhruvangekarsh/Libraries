<?php
class Calendar { 
	public function __construct(){     
        $this->naviHref = htmlentities($_SERVER['PHP_SELF']);
    }

    private $dayLabels 		= array("Mon","Tue","Wed","Thu","Fri","Sat","Sun");
     
    private $currentYear	= 0;
     
    private $currentMonth	= 0;
     
    private $currentDay		= 0;
     
    private $currentDate 	= NULL;
     
    private $daysInMonth	= 0;
     
    private $naviHref		= NULL;
	
	
	public function show() {
		
        $year  = NULL; 
        $month = NULL;
         
        if( $year == NULL && isset($_GET['year'])){ $year = $_GET['year'];
         
        }else if( $year == NULL ){ $year = date("Y",time()); }          
         
        if( $month == NULL && isset($_GET['month'])){  $month = $_GET['month'];
         
        }else if( $month == NULL ){ $month = date("m",time()); } 
		                  
        $this->currentYear	= $year;
        $this->currentMonth	= $month; 
        $this->daysInMonth	= cal_days_in_month(0, $month, $year); 
		
		$content 	= '<table class="table table-bordered">'; 
		$content   .= $this->_createNavi();
		$content   .= $this->_createLabels();
		
		$weeksInMonth = $this->_weeksInMonth($month,$year);
		
		for( $i = 0; $i < $weeksInMonth; $i++ ){
			for( $j = 1; $j <= 7; $j++){
            	$content .= $this->_showDay($i*7+$j);
				if($j%7 == 0){$content .= '</tr><tr>';}
			}		
		}
 
		$content   .= '</table>'; 
		
        return $content;   
    }
	
	
	
	private function _showDay($cellNumber){
         
        if($this->currentDay == 0){
            $firstDayOfTheWeek = date('N',strtotime($this->currentYear.'-'.$this->currentMonth.'-01'));         
            if(intval($cellNumber) == intval($firstDayOfTheWeek)){ $this->currentDay = 1; }
        }
         
        if( ($this->currentDay!=0)&&($this->currentDay<=$this->daysInMonth) ){
            $this->currentDate = date('Y-m-d',strtotime($this->currentYear.'-'.$this->currentMonth.'-'.($this->currentDay)));
            $cellContent = $this->currentDay;
             
            $this->currentDay++;   
             
        }else{
             
            $this->currentDate = NULL;
 
            $cellContent = NULL;
        }
		
			
		if(strtotime($this->currentDate) > time()){ $flag = "future"; } 	// Future dates
		else { $flag = "past"; } 											// Past dates	
		
		if($this->currentDate == date('Y-m-d')){$flag = "current";}			// Current dates
		
		$content	= '<td class="'.$flag.' '.($cellNumber%7==1?' start ':($cellNumber%7==0?' end ':' ')).($cellContent==null?'mask':'').'" id="li-'.$this->currentDate.'">';
		$content   .= '<label for="'.$this->currentDate.'"><input type="radio" class="dates" name="date" id="'.$this->currentDate.'" value="'.$this->currentDate.'"/>';
		$content   .= $cellContent;
		$content   .= "</label></td>";
		
		return($content);
				
    }
	
	private function _createNavi(){
		
		$year  = NULL; $month = NULL;
         
        if( $year == NULL && isset($_GET['year'])){ $year = $_GET['year'];
         
        }else if( $year == NULL ){ $year = date("Y",time()); }          
         
        if( $month == NULL && isset($_GET['month'])){  $month = $_GET['month'];
         
        }else if( $month == NULL ){ $month = date("m",time()); }                  
         
        $this->currentYear 	= $year;
		
        $this->currentMonth = $month;
         
        $this->daysInMonth	= cal_days_in_month(0, $month, $year); 
         
        $nextMonth 			= $this->currentMonth==12?1:intval($this->currentMonth)+1;
         
        $nextYear 			= $this->currentMonth==12?intval($this->currentYear)+1:$this->currentYear;
         
        $preMonth 			= $this->currentMonth==1?12:intval($this->currentMonth)-1;
         
        $preYear 			= $this->currentMonth==1?intval($this->currentYear)-1:$this->currentYear;
		
		$head 			    = '<tr>'; 
		$head			   .= '<th><a class="prev" href="'.$this->naviHref.'?month='.sprintf('%02d',$preMonth).'&year='.$preYear.'">Prev</a></th>';	
		$head			   .= '<th colspan="5"><span class="title">'.date('Y M',strtotime($this->currentYear.'-'.$this->currentMonth.'-1')).'</span>';	
		$head			   .= '<th><a class="next" href="'.$this->naviHref.'?month='.sprintf("%02d", $nextMonth).'&year='.$nextYear.'">Next</a></th>';	
		$head 			   .= '</tr>';  
		
		return($head);
		
    }
         
    
    private function _createLabels(){  
	
		$content	= '<tr>';		
        foreach($this->dayLabels as $index=>$label){ $content   .= '<th>'.$label.'</th>'; }  
		$content   .= '</tr>';
        return $content;
    }
	
	private function _weeksInMonth($month = NULL, $year = NULL){
         
        if( $year == NULL ) $year =  date("Y",time()); 
        if( $month == NULL ) $month = date("m",time());
         
        // Returns Number of Days in this Month
		$daysInMonths = cal_days_in_month(0, $month, $year); 					
         
		// Returns Number of Weeks in this Month 
        $numOfweeks = ($daysInMonths%7 == 0 ? 0 : 1) + intval($daysInMonths/7);
         
		// Returns end Day of this Month 
        $monthEndingDay= date('N',strtotime($year.'-'.$month.'-'.$daysInMonths)); 
         
		// Returns start Day of this Month  
        $monthStartDay = date('N',strtotime($year.'-'.$month.'-01'));
         
        if( $monthEndingDay < $monthStartDay ) { $numOfweeks++; }
         
        return $numOfweeks;
    }
 
	
	
}