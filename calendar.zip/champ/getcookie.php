<?php

	if(isset($_POST['data'])){
		$delete_date = $_POST['data'];
		$tempdata = unserialize($_COOKIE['tempData']); 
		unset($tempdata[$delete_date]);
		setcookie('tempData', serialize($tempdata));
		$delay=0; 
		header("Refresh: $delay;"); 
	}

	function chips($str){
		$arr = explode('-',$str);
		echo '<ul>';
		foreach($arr as $el){
			echo '<li>'.$el.'</li>';
		}
		echo '</ul>';
	}

	function showData(){
		if(isset($_COOKIE['tempData'])) {
			$tempdata = unserialize($_COOKIE['tempData']); 
			echo '<table class="table table-bordered temp	">';
			foreach($tempdata as $date => $time){
				echo '<tr>';
				echo '<td width="100"><label><input type="text" id="mytempdate" value="'.$date.'" readonly/></label></td>';
				echo '<td width="200"><label><input type="text" id="mytemptime" value="'.$time.'" readonly/></label></td>';
				echo '<td width="50"><label><button class="removeTemp">X</button></label></td>';
				echo '</tr>';	
			}
			echo '</table">';
		}
	}
	
	showData();
	
?>